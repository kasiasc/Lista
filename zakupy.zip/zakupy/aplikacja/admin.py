from django.contrib import admin
from aplikacja.models import Product, Page

admin.site.register(Product)
admin.site.register(Page)
# Register your models here.
