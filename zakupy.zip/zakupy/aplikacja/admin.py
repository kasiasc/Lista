from django.contrib import admin
from aplikacja.models import Product, List

admin.site.register(Product)
admin.site.register(List)
# Register your models here.
